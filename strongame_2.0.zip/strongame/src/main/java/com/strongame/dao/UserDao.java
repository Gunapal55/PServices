package com.strongame.dao;

import java.util.List;

import com.strongame.entity.UserInformation;
import com.strongame.entity.UserStepsStats;

public interface UserDao {

	public UserInformation registerUser(UserInformation newRegister);

	public UserInformation updateUser(UserInformation update);

	public UserInformation getUserByEmail(String userEmail);

	public List<UserInformation> getAllUsers();

	public UserStepsStats trackSteps(UserStepsStats userSteps);

	public List<UserInformation> authenticateUser();

	public UserInformation forgotPassword(String email, String password);

}
