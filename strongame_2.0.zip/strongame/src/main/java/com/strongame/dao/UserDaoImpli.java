package com.strongame.dao;

import java.lang.reflect.Type;
import java.util.List;

/*
 * @author gunapal.p
 */
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.stereotype.Repository;

import com.strongame.dto.UserInformationDto;
import com.strongame.entity.UserInformation;
import com.strongame.entity.UserStepsStats;
import com.strongame.exception.UserException;

@Repository
public class UserDaoImpli implements UserDao {

	@PersistenceContext
	EntityManager manager;

	@Override
	@Transactional
	public UserInformation registerUser(UserInformation newRegister) {

		manager.persist(newRegister);
		return newRegister;
	}

	@Override
	@Transactional
	public UserStepsStats trackSteps(UserStepsStats userSteps) {

		manager.merge(userSteps);
		return userSteps;
	}

	@Override
	@Transactional
	public UserInformation updateUser(UserInformation info2) {

		manager.merge(info2);
		return info2;

	}

	@Override
	public UserInformation getUserByEmail(String userEmail) {

		TypedQuery<UserInformation> query = manager
				.createQuery("select u from UserInformation u where u.userEmail= :value", UserInformation.class);
		query.setParameter("value", userEmail);
		return query.getSingleResult();

	}

	@Override
	public List<UserInformation> getAllUsers() {

		TypedQuery<UserInformation> query = manager.createQuery("from UserInformation", UserInformation.class);
		List<UserInformation> users = query.getResultList();
		ModelMapper mapper = new ModelMapper();
		Type listType = new TypeToken<List<UserInformationDto>>() {
		}.getType();
		return mapper.map(users, listType);

	}

	@Override
	@Transactional
	public UserInformation forgotPassword(String email, String password) {

		TypedQuery<UserInformation> query = manager.createQuery(
				"select u from UserInformation u where u.userEmail= :value or u.userPhoneNumber= :value",
				UserInformation.class);
		query.setParameter("value", email);
		UserInformation info = query.getSingleResult();

		if (info != null) {
			info.setPassword(password);
			info.setConfirmPassword(password);
			updateUser(info);
			return info;
		} else {
			throw new UserException("Given email or phone number is incorrect!");
		}

	}

	@Override
	public List<UserInformation> authenticateUser() {

		TypedQuery<UserInformation> query = manager.createQuery("from UserInformation", UserInformation.class);
		return query.getResultList();

	}

}
