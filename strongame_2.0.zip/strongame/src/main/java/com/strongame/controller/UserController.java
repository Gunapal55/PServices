package com.strongame.controller;
/*
 * @author gunapal.p
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.strongame.dto.AuthenticationResponse;
import com.strongame.dto.ResponseDto;
import com.strongame.dto.UserInformationDto;
import com.strongame.dto.UserStepsStatsDto;
import com.strongame.entity.UserInformation;
import com.strongame.service.JwtUtil;
import com.strongame.service.MyUserDetailsService;
import com.strongame.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private MyUserDetailsService userDetailsService;

	@Autowired
	private JwtUtil jwtTokenUtil;

	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody UserInformationDto authenticationRequest)
			throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
					authenticationRequest.getUserEmail(), authenticationRequest.getPassword()));
		}

		catch (BadCredentialsException e) {
			throw new BadCredentialsException("Incorrect username or password", e);
		}

		final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUserEmail());

		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}

	@PostMapping("/register")
	public ResponseDto addProduct(@RequestBody UserInformationDto data) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.registerUser(data));
		return dto;
	}

	@PutMapping("/profile")
	public ResponseDto updateUser(@RequestBody UserInformation userUpdate) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.updateUser(userUpdate));
		return dto;
	}

	@GetMapping("/{userEmail}")
	public ResponseDto getUserByEmail(@PathVariable String userEmail) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.getUserByEmail(userEmail));
		return dto;
	}

	@GetMapping("/users")
	public ResponseDto getAllUsers() {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.getAllUsers());
		return dto;
	}

	@PutMapping("/steps")
	public ResponseDto trackSteps(@RequestBody UserStepsStatsDto userSteps) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.trackSteps(userSteps));
		return dto;
	}

	@PutMapping("/forgtpassword")
	public ResponseDto forgotPassword(@RequestParam String email, @RequestParam String password) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.forgotPassword(email, password));
		return dto;
	}

}
