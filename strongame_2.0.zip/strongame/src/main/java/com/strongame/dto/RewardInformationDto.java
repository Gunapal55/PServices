package com.strongame.dto;

import lombok.Data;

@Data
public class RewardInformationDto {

	private int rewardsInformationId;

	private double noOfSteps;

	private double rewardsCoins;

}
