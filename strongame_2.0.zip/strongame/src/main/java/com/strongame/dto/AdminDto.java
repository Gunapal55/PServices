package com.strongame.dto;

import lombok.Data;

@Data
public class AdminDto {

	private String userName;

	private String password;
}
