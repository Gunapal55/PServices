package com.strongame.dto;

import lombok.Data;

@Data
public class ProductInformationDto {

	private int productId;

	private String productName;

	private String productDescription;

	private String productFeatures;

	private String productDisclaimer;

	private double productCoins;

	private double productImages;

}
