package com.strongame.dto;
/*
 * @author gunapal.p
 */
import lombok.Data;

@Data
public class BannerInformationDto {

	private int bannerInfoId;

	private String bannerName;

	private String bannerDisplayPage;

	private String bannerStatus;

	private String bannerImages;

}
