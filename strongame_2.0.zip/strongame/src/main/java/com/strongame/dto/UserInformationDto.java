package com.strongame.dto;
/*
 * @author gunapal.p
 */
import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class UserInformationDto implements Serializable {

	private static final long serialVersionUID = 8222627122512465779L;

	private int userId;

	private String name;

	private Date userDob;

	private String userEmail;

	private String password;

	private String confirmPassword;

	private long userPhoneNumber;

	private String referalCode;
	
	private double height;
	
	private double weight;
	
	private String gender;
	
	private String photo;

}
