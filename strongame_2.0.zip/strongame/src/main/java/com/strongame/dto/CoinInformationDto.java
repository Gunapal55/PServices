package com.strongame.dto;
/*
 * @author gunapal.p
 */

import lombok.Data;

@Data
public class CoinInformationDto {

	private int coinsId;

	private String coinsDescription;

	private double totalCoins;

	private double balanceCoins;

	private double coin;

}
