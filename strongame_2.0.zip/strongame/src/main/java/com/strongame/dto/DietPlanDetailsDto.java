package com.strongame.dto;
/*
 * @author gunapal.p
 */

import lombok.Data;

@Data
public class DietPlanDetailsDto {
	
	private int dietId;

	private String dietName;

	private double calories;

	private double protine;

	private double fat;

	private double carbs;

	private String dietDetails;

	private String dietImage;

	private String dietVideo;

	private String dietDisplayPage;

}
