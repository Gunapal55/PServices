package com.strongame.dto;

import java.util.Date;

import com.strongame.entity.UserInformation;

import lombok.Data;

/*
 * @author gunapal.p
 */
@Data
public class UserStepsStatsDto {

	private int stepId;

	private Date day;

	private double week;

	private double month;

	private int year;

	private double distanceInKm;

	private double caloriesBurent;

	private double totalCalories;

	private int currentSteps;

	private int targetSteps;

	private double coinsEarned;

	private UserInformation userId;

}
