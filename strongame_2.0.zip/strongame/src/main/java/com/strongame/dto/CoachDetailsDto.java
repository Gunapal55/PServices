package com.strongame.dto;

import java.util.List;

import com.strongame.entity.PlanInformation;

import lombok.Data;

@Data
public class CoachDetailsDto {

	private int coachId;

	private String coachName;

	private String specialization;

	private String certifications;

	private String coachDetail;

	private long phone;

	private double rating;

	private String rankType;

	private String photo;

	private String coachDisplayPage;

	private int coachTrained;

	private List<PlanInformation> plans;

}
