package com.strongame.dto;

import java.util.Date;

import lombok.Data;

@Data
public class OrderInformationDto {

	private int orderId;

	private String orderStatus;

	private String address;

	private String message;

	private Date orderDate;
}
