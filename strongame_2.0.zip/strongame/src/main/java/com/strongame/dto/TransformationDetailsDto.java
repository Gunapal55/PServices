package com.strongame.dto;

import lombok.Data;
@Data 
public class TransformationDetailsDto {

	private int transformationId;

	private String transformationTitle;

	private String transformationDetail;

	private String transformationVideoUrl;

	private String transformationDisplayPage;
	
}
