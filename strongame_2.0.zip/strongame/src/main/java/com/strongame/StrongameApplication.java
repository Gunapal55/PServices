package com.strongame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrongameApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrongameApplication.class, args);

	}

}
