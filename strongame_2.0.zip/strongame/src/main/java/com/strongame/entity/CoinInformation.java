
package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "coin_information")
@NoArgsConstructor
@AllArgsConstructor
public class CoinInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "coins_id")
	private int coinsId;

	@Column(name = "coins_description")
	private String coinsDescription;

	@Column(name = "total_coins")
	private double totalCoins;

	@Column(name = "balance_coins")
	private double balanceCoins;

	@Column(name = "coin")
	private double coin;
	
	

}
