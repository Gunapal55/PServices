package com.strongame.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "admin_information")
@NoArgsConstructor
@AllArgsConstructor
public class AdminInformation implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5646461742505767488L;

	@Id
	@Column(name = "admin_email")
	private String adminEmail;


	@Column(name = "admin_password")
	private String adminPassword;
	
	@Column(name = "admin_age")
	private String adminAge;
	
	

}
