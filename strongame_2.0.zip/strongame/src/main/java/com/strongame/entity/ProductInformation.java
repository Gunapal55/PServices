package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "product_information")
@NoArgsConstructor
@AllArgsConstructor
public class ProductInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private int productId;

	@Column(name = "product_name")
	private String productName;

	@Column(name = "product_description")
	private String productDescription;

	@Column(name = "product_features")
	private String productFeatures;

	@Column(name = "product_disclaimer")
	private String productDisclaimer;

	@Column(name = "product_coins")
	private double productCoins;

	@Column(name = "product_images")
	private double productImages;

}
