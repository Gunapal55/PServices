package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "banner_information")
@NoArgsConstructor
@AllArgsConstructor
public class BannerInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "banner_info_id")
	private int bannerInfoId;

	@Column(name = "banner_name")
	private String bannerName;

	@Column(name = "banner_display_page")
	private String bannerDisplayPage;

	@Column(name = "banner_status")
	private String bannerStatus;

	@Column(name = "banner_images")
	private String bannerImages;

}
