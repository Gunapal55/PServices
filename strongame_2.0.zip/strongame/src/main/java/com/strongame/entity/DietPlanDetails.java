package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "diet_plan_detail")
@NoArgsConstructor
@AllArgsConstructor
public class DietPlanDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "diet_id")
	private int dietId;

	@Column(name = "diet_name")
	private String dietName;

	@Column(name = "calories")
	private double calories;

	@Column(name = "protine")
	private double protine;

	@Column(name = "fat")
	private double fat;

	@Column(name = "carbs")
	private double carbs;

	@Column(name = "diet_details")
	private String dietDetails;

	@Column(name = "diet_img")
	private String dietImage;

	@Column(name = "diet_video")
	private String dietVideo;

	@Column(name = "diet_display_page")
	private String dietDisplayPage;

}
