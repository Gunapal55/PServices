package com.strongame.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "order_information")
@NoArgsConstructor
@AllArgsConstructor
public class OrderInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "order_id")
	private int orderId;

	@Column(name = "order_status")
	private String orderStatus;

	@Column(name = "address")
	private String address;
	
	@Column(name = "message")
	private String message;

	@Column(name = "order_date")
	private Date orderDate;
	
}
