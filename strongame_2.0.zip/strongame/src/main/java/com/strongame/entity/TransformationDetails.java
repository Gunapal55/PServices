package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "transformation_detials")
@NoArgsConstructor
@AllArgsConstructor
public class TransformationDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transformation_id")
	private int transformationId;

	@Column(name = "transformation_title")
	private String transformationTitle;

	@Column(name = "transformation_detail")
	private String transformationDetail;

	@Column(name = "transformation_video_url")
	private String transformationVideoUrl;

	@Column(name = "transformation_display_page")
	private String transformationDisplayPage;
}
