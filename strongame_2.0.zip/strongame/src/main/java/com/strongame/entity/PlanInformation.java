package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "plan_information")
@NoArgsConstructor
@AllArgsConstructor
public class PlanInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "plan_id")
	private int planId;

	@NotNull
	@Column(name = "plan_name")
	private String planName;

	@NotNull
	@Column(name = "plan_details")
	private String planDetails;

	@NotNull
	@Column(name = "plan_price")
	private double planPrice;

}
