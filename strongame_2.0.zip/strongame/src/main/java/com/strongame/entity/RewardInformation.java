package com.strongame.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "rewards_information")
@NoArgsConstructor
@AllArgsConstructor
public class RewardInformation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "rewards_info_id")
	private int rewardsInformationId;

	@Column(name = "no_of_steps")
	private double noOfSteps;

	@Column(name = "rewards_coins")
	private double rewardsCoins;

}
