package com.strongame.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "coach")
@NoArgsConstructor
@AllArgsConstructor
public class CoachDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "coach_id")
	private int coachId;

	@NotNull
	@Column(name = "coach_name")
	private String coachName;

	@NotNull
	private String specialization;

	@NotNull
	private String certifications;

	@NotNull
	@Column(name = "coach_details")
	private String coachDetail;

	@NotNull
	@Column(name = "phone")
	private long phone;

	@NotNull
	private double rating;

	@NotNull
	@Column(name = "rank_type")
	private String rankType;

	@NotNull
	private String photo;

	@Column(name = "coach_display_page")
	private String coachDisplayPage;

	@Column(name = "no_of_user_trained")
	private int coachTrained;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "coach_id", referencedColumnName = "coach_id")
	private List<PlanInformation> plans;

}
