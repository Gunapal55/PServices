package com.strongame.service;

import java.util.List;

import com.strongame.dto.UserInformationDto;
import com.strongame.dto.UserStepsStatsDto;
import com.strongame.entity.UserInformation;

public interface UserService {

	public UserInformationDto registerUser(UserInformationDto register);

	public UserInformation updateUser(UserInformation update);

	public UserInformationDto getUserByEmail(String userEmail);

	public UserStepsStatsDto trackSteps(UserStepsStatsDto userSteps);
	
	public UserInformation forgotPassword(String email, String password);

	public List<UserInformationDto> getAllUsers();

}
