package com.strongame.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.strongame.dao.UserDao;
import com.strongame.entity.UserInformation;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private UserDao dao;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		List<UserInformation> data = dao.authenticateUser();
		User users = null;

		for (UserInformation info : data) {

			users = new User(info.getUserEmail(), info.getPassword(), new ArrayList<>());

		}

		return users;
	}

}
