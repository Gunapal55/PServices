package com.strongame.service;
/*
 * @author gunapal.p
 */

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.strongame.dao.UserDao;
import com.strongame.dto.UserInformationDto;
import com.strongame.dto.UserStepsStatsDto;
import com.strongame.entity.UserInformation;
import com.strongame.entity.UserStepsStats;
import com.strongame.exception.UserException;

@Service
public class UserServicesImpli implements UserService {

	@Autowired
	private UserDao dao;

	@Override
	public UserInformationDto registerUser(UserInformationDto register) {

		try {
			if (register != null) {
				UserInformation newRegister = new UserInformation();
				BeanUtils.copyProperties(register, newRegister);
				newRegister = dao.registerUser(newRegister);
				BeanUtils.copyProperties(newRegister, register);
			}
			return register;
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException("Failed to register new user: User details are missing!!");
		}
	}

	@Override
	public UserStepsStatsDto trackSteps(UserStepsStatsDto userSteps) {

		try {
			if (userSteps != null) {

				UserStepsStats trackSteps = new UserStepsStats();
				BeanUtils.copyProperties(userSteps, trackSteps);
				trackSteps = dao.trackSteps(trackSteps);
				BeanUtils.copyProperties(trackSteps, userSteps);
			}
			return userSteps;
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException("Failed to Add new steps: User Steps details are missing!!");
		}
	}

	@Override
	public UserInformation updateUser(UserInformation update) {

		try {
			if (update != null) {

				UserInformation info = new UserInformation();
				BeanUtils.copyProperties(update, info);
				update = dao.updateUser(update);

			}
			return update;
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException("Failed to update user profile: User details are missing!!");
		}
	}

	@Override
	public UserInformationDto getUserByEmail(String userEmail) {

		try {
			UserInformationDto dto = new UserInformationDto();
			if (userEmail != null) {

				UserInformation result = dao.getUserByEmail(userEmail);
				BeanUtils.copyProperties(result, dto);
			}
			return dto;
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException("Failed to fetch user by email: Please check the given Email!!");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserInformationDto> getAllUsers() {
		try {
			List<UserInformationDto> dto = (List<UserInformationDto>) new UserInformationDto();
			List<UserInformation> result = dao.getAllUsers();
			if (result != null) {
				BeanUtils.copyProperties(result, dto); 

			}
			return dto;

		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException("Failed to fetch Users: No users found in database!!");
		}
	}

	@Override
	public UserInformation forgotPassword(String email, String password) {

		return dao.forgotPassword(email, password);

	}

}