import axios from "axios";
import React from "react";

export default class Form extends React.Component {
      
    state={
                email: "",
                newpassword: "",
                confirmPassword: ""
                }
        

  change = e => {
   this.setState({
      [e.target.name]: e.target.value
    });
  };

  onSubmit = e => {
    e.preventDefault();
    console.log(this.state);
  
    axios({
        method: 'post',
        url: '/forgotpwdurl',
        data: this.state
    })
    .then(function (response) {
        console.log(response);
    })
    .catch(function (error) {
        console.log(error);
    });
};
  
  render() {
    return (
      <form>
     <input
          name="email"
          placeholder="Email"
          value={this.state.email}
          onChange={e => this.change(e)}
        />
        <br />
        <input
          name="newpassword"
          type="password"
          placeholder="Password"
          value={this.state.newpassword}
          onChange={e => this.change(e)}
        />
        <br />

        <input
          name="confirmPassword"
          type="password"
          placeholder="Confirm Password"
          value={this.state.confirmPassword}
          onChange={e => this.change(e)}
        />
        <button onClick={e => this.onSubmit(e)}>Submit</button>
      </form>
    );
  }
}
