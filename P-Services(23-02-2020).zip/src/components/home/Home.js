import React, { Component } from 'react'
import './Home.css'
import Container from '@material-ui/core/Container';


export default class WelcomePage extends Component {
    render() {
        return (
            <div className="welcomePage">
                <Container style={{marginLeft:'25px'}} maxWidth="lg">
                {/* Home Page Styling goes here */}
                <h2 style={{marginLeft:'400px'}}>'TEST YANTRA' – The energy behind our QA services</h2>
                <br/>
          <img src="https://www.testyantra.com/sites/default/files/inline-images/WAY-US-New.jpg"></img>
    <h4> 
    Yantra (यन्त्र) is a Sanskrit word for "machine" or "instrument".
    The word Yantra (यन्त्र) is derived from the root 'yam' meaning to sustain,
    hold or support.  
    ‘Test Yantra’ symbolizes the automated and expert contrivance that harness the energy and 
    experience of the organization to make our client’s business successful through full range QA services.</h4>
  </Container>
            </div>
        )
    }
}
