import axios from "axios";
import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";
import * as ReactDOM from "react-dom";
import { JsonToCsv, useJsonToCsv } from "react-json-csv";
import MUIDataTable from "mui-datatables";
import Container from '@material-ui/core/Container';

function EmpToCSV() {
  const jondata = JSON.parse(myjson);

  console.log(jondata);

  const filename = "TY-Development-Employee Details",
    fields = {
      empid: "Employee ID",
      FullName: "Full Name",
      Gender: "Gender",
      ContactNum: "ContactNum",
      AlternateNum: "AlternateNum",
      Officilemail: "Officilemail",
      Personelemail: "Personelemail",
      Yearofpass: "Yearofpass",
      Stream: "Stream",
      Higherqualify: "Higherqualify",
      Dateofjoin: "Dateofjoin",
      Expirience: "Expirience",
      Skillonfrondend: "Skillonfrondend",
      Skillonbackend: "Skillonbackend",
      Permanentaddress: "Permanentaddress",
      Tempaddress: "Tempaddress",
      City: "City",
      State: "State",
      Pincode: "Pincode",
    },
   
    style = {
      padding: "5px",
    },
  
    text = "Convert Json to Csv";

  <JsonToCsv
    data={myjson}
    filename={filename}
    fields={fields}
    style={style}
    text={text}
  />;

  const { saveAsCsv } = useJsonToCsv();


  const options = {
    filterType: "dropdown",
    responsive: "scroll"
  };

  return (
    <div  style={{display:'flex' , justifyContent:'center'}}>
      <button onClick={(e) => saveAsCsv({ myjson, fields, filename })} >
        Download as Excel
      </button>
    </div>
  );
}

export default class EmployeeList extends Component {
  render() {
<EmpToCSV />
    const columns = ["empid", "FullName", "Gender", "ContactNum", "AlternateNum", "Officilemail", "Personelemail", "Yearofpass", "Stream","Higherqualify", "Dateofjoin", "Expirience", "Skillonfrondend","Skillonbackend", "Permanentaddress", "Tempaddress","City", "State", "Pincode" ];
   
    return (
      <Container style={{marginLeft:30}}>
      <MUIDataTable
      title={"TY Employee Details List"}
      data={myjson}
      columns={columns}
      options={this.options}
        />
       </Container>
    );
  }
}
