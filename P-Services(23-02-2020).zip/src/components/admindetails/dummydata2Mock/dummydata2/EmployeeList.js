import axios from "axios";
import React, { Component } from "react";
import myjson from "./data.json";
import "./Employee.css";
import * as ReactDOM from "react-dom";
import { JsonToCsv, useJsonToCsv } from "react-json-csv";
import MUIDataTable from "mui-datatables";
import Container from '@material-ui/core/Container';

function EmpToCSV() {
  const jondata = JSON.parse(myjson);

  console.log(jondata);

  const filename = "TY-Mock-Feedback-Details",
    fields = {
      empid: "Employee ID",
      FullName: "Name",
      Mockdate: "Mock Date",
      MockTakenBY: "Mock Taken By",
      Technology: "Technology Known",
      PracticalScore: "Practical Score",
      TheoriticalScore: "Theoritical Score",
      OverallFeedback: "Over All Feedback",
      ActionItem: "Action Taken",
      Detailedfeedback: "Higher Qualification",
     },
   
    style = {
      padding: "5px",
    },
  
    text = "Convert Json to Csv";

  <JsonToCsv
    data={myjson}
    filename={filename}
    fields={fields}
    style={style}
    text={text}
  />;

  const { saveAsCsv } = useJsonToCsv();


  const options = {
    filterType: "dropdown",
    responsive: "scroll"
  };

  return (
    <div  style={{display:'flex' , justifyContent:'center'}}>
      <button onClick={(e) => saveAsCsv({ myjson, fields, filename })} >
        Download as Excel
      </button>
    </div>
  );
}

export default class EmployeeListFinal extends Component {
  render() {
<EmpToCSV />
    const columns = ["empid", "FullName", "Mockdate", "MockTakenBY", "Technology", "PracticalScore", "TheoriticalScore", "OverallFeedback", "ActionItem","Detailedfeedback"];
   
    return (
      <Container style={{marginLeft:30}} >
    <MUIDataTable
    title={"TY Mock Feedback List"}
    data={myjson}
    columns={columns}
    options={this.options}
      />
     </Container>
    );
  }
}
