 import React, { useState, useEffect } from 'react'
import Controls from "../admindetails/feedbackform/assets/controls/Controls";
import { useForm, Form } from "../admindetails/feedbackform/assets/useForm";
import  * as employeeService from "../admindetails/feedbackform/services/employeeService";
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { Container, TextField } from '@material-ui/core';
import '../admindetails/feedbackform/pages/EmployeeForm.css'


const genderItems = [
    { id: 'male', title: 'Male' },
    { id: 'female', title: 'Female' },
    { id: 'other', title: 'Other' },
]

const initialFValues = {
    id: '',
    fullName: '',
    offemail:'',
    email: '',
    contactNumber: '',
    altContactNumber: '',
    yop:'',
    hqualification:'',
    doj:new Date(),
    exp:'',
    skillsF:'',
    skillsB:'',
    city: '',
    gender: 'male',
    pincode:'',
    state:'',
    paddress:'',
    taddress:'',
}

export default function EmployeeFormUpdate() {

    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('fullName' in fieldValues)
            temp.fullName = fieldValues.fullName ? "" : "This field is required."
            if ('hqualification' in fieldValues)
            temp.hqualification = fieldValues.hqualification ? "" : "This field is required."
            if ('skillsF' in fieldValues)
            temp.skillsF = fieldValues.skillsF ? "" : "This field is required."
            if ('skillsB' in fieldValues)
            temp.skillsB = fieldValues.skillsB ? "" : "This field is required."
            if ('yop' in fieldValues)
            temp.yop = fieldValues.yop ? "" : "This field is required."
        if ('contactNumber' in fieldValues)
            temp.contactNumber = fieldValues.contactNumber.length > 9 ? "" : "Minimum 10 numbers required."
            if ('pincode' in fieldValues)
            temp. pincode = fieldValues. pincode.length > 6 ? "" : "Minimum 6 numbers required."
            if ('paddress' in fieldValues)
            temp.paddress = fieldValues.paddress ?  "" : "Address is required."
        if ('id' in fieldValues)
            temp.id = fieldValues.id.length != 0 ? "" : "This field is required."
        setErrors({
            ...temp
        })

        if (fieldValues === values)
            return Object.values(temp).every(x => x === "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFValues, true, validate);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()){
            employeeService.insertEmployee(values)
            resetForm()
        }
    }

    return (
 <Container justify="center" maxWidth="md">
   <Card>
     <CardContent>
        <Form onSubmit={handleSubmit}>
            <br></br>
            <br></br>
            <br></br>
            <Grid container spacing={2}>
                <Grid item xs={6}>
                <Controls.Input
                        name="id"
                        label="Employee ID"
                        value="TYC123"
                        onChange={handleInputChange}
                        error={errors.id}
                    />
                    <Controls.Input
                        name="fullName"
                        label="Full Name"
                        value="Gunapal"
                        onChange={handleInputChange}
                        error={errors.fullName}
                    />
                    {/* <Grid align="left">       Hello             </Grid> */}

                     <Controls.RadioGroup
                        name="gender"
                        label="Gender"
                        value={values.gender}
                        onChange={handleInputChange}
                        items={genderItems}
                    />
                     <Controls.Input
                        label="Contact Number"
                        name="contactNumber"
                        value="9156784539"
                        onChange={handleInputChange}
                        error={errors.contactNumber}
                    />
                     <Controls.Input
                        label="Alternate Contact Number"
                        name="altContactNumber"
                        value="9167852345"
                        onChange={handleInputChange}
                        error={errors.mobile}
                    />
                    <Controls.Input
                        label="Official Email"
                        name="email"
                        value="gunapal.p@testyantra.in"
                        onChange={handleInputChange}
                        error={errors.email}
                    />
                    <Controls.Input
                        label="Personal Email"
                        name="offemail"
                        value="gunapal@gmail.com"
                        onChange={handleInputChange}
                        error={errors.offemail}
                    />
                   
                   
                     <Controls.Input
                        label="Year Of Passout"
                        name="yop"
                        value="2019"
                        onChange={handleInputChange}
                        error={errors.yop}
                    />
                         <Controls.Input
                        label="Highest Qualification"
                        name="hqualification"
                        value="B.E"
                        onChange={handleInputChange}
                        error={errors.hqualification}
                    />
                                       <form>

                    </form>
                </Grid>
                
                <Grid item xs={6}>
                <Controls.DatePicker
                    label="Date of Joining"
                    name="doj"
                    value="2020-02-24"
                    onChange={handleInputChange}
                    />
                <Controls.Input
                        label="Exprience"
                        name="exp"
                        value="1 year"
                        onChange={handleInputChange}
                        error={errors.exp}
                    />
                     <Controls.Input
                        label="Skills On FrontEnd Technology"
                        name="skillsF"
                        value="html,css,react js"
                        onChange={handleInputChange}
                        error={errors.skillsF}
                    />
                     <Controls.Input
                        label="Skills On BackEnd Technology"
                        name="skillsB"
                        value="spring,java,jdbc"
                        onChange={handleInputChange}
                        error={errors.skillsB}
                    />
                      <Controls.Input
                        label="Permanent Address"
                        name="paddress"
                        value="Mysore"
                        onChange={handleInputChange}
                        error={errors.paddress}
                    />
                    
                    <Controls.Input
                        label="Temporary Address"
                        name="taddress"
                        value="Rajajinagar"
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="City"
                        name="city"
                        value="Bangalore"
                        onChange={handleInputChange}
                    />   
                    
                    
                    <Controls.Input
                        label="State"
                        name="state"
                        value="Karnataka"
                        onChange={handleInputChange}
                    />
                    
                    <Controls.Input
                        label="Pincode"
                        name="pincode"
                        value="560062"
                        onChange={handleInputChange}
                        error={errors.pincode}
                    />
                 <div m={1} >
                        <Controls.Button
                            type="submit"
                            text="Submit" />
                           <Controls.Button
                            text="Reset"
                            color="default"
                            onClick={resetForm} />
                       </div>

                </Grid>
            </Grid>
        </Form>
        </CardContent>
        </Card>
        </Container>
        
    )
}