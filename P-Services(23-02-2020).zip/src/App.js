import MainRouting from './components/router/MainRouting';
import ForgotPassword from './components/forms/ForgotPassword';

function App() {
  return (
    <div className="App">
      <MainRouting/>
    {/* <ForgotPassword /> */}

    </div>
  );
}

export default App;
