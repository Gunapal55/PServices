package com.tyss.pservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
