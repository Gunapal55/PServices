package com.tyss.pservices.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tyss.pservices.entity.MockFeedBackDetails;
import com.tyss.pservices.service.MockService;

@RestController
public class MockController {

	@Autowired
	private MockService service;

	@CrossOrigin
	@PostMapping("/mockfeedback")
	protected MockFeedBackDetails addFeedback(@RequestBody MockFeedBackDetails mockFeedback) {
		return service.saveMockDetails(mockFeedback);
	}

	@CrossOrigin
	@GetMapping("/mockfeedbacks")
	protected List<MockFeedBackDetails> getAllFeedback() {
		return service.getAllFeedbacks();
	}

	@CrossOrigin
	@GetMapping("/mockfeedback/{id}")
	protected MockFeedBackDetails getMockFeedbackById(@PathVariable Integer id) {
		return service.getFeedbackById(id);
	}
	
	@CrossOrigin
	@DeleteMapping("/mockfeedbackdetials/{id}")
	protected String deleteById(@PathVariable Integer id) {
		return service.deleteMockById(id);
	}
	
	
}
