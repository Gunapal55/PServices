package com.tyss.pservices.dto;

public interface MockDto {

	
	
}
