package com.tyss.pservices.dao;

public class MockDaoImple {
	

}
