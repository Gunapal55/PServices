package com.tyss.pservices.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tyss.pservices.entity.MockFeedBackDetails;


public interface MockDao extends JpaRepository<MockFeedBackDetails,Integer>{

	
}
