package com.tyss.pservices.service;

import java.util.List;

import javax.print.attribute.standard.MediaSize.Other;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tyss.pservices.dao.MockDao;
import com.tyss.pservices.entity.MockFeedBackDetails;

@Service
public class MockService {

	@Autowired
	private MockDao repo;
	
	public MockFeedBackDetails saveMockDetails(MockFeedBackDetails mockDetails) {
		return repo.save(mockDetails);
	}
	
	public List<MockFeedBackDetails> getAllFeedbacks(){
		return repo.findAll();
	}
	
	public MockFeedBackDetails getFeedbackById(Integer id){
		return repo.findById(id).orElse(null);
	}
	
	public String deleteMockById(Integer id) {
		repo.deleteById(id);
		return "MockFeedBack Removed! for id: " +id;
	}
	
	
}
