package com.tyss.pservices.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name="mockfeedback")
@Entity
@AllArgsConstructor	
@NoArgsConstructor
@Data
public class MockFeedBackDetails {

		
		@Id
		private Integer empid;
		
		private String fullName;
		
		private Date mockdate;
				
		private String mocktakenby;
		
		private String technology;
		
		private Integer therotical;
					
		private Integer pratical;
		
		private String overall;
		
		private String detailedfeedback;
		
	
}
