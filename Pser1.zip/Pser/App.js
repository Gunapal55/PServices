import './App.css';
import PrimarySearchAppBar from './components/Navbar';
// import InputForm from './InputForm';
import { BrowserRouter as Router, Route } from "react-router-dom";
import SignInSide from './components/SignInSide';
import SignUp from './components/SignUpSide';
import { MaterialUIFormSubmit } from './components/MockFeedBack';



function App() {
  return (
<Router>
    <div className="App">
      <PrimarySearchAppBar/>

      
      <Route path="/signin" exact component={SignInSide} />
        <Route exact path="/signup" component={SignUp} />
        <Route exact path="/feedback" component={MaterialUIFormSubmit} />

        
      
      {/* <InputForm/> */}
    </div>
    </Router>
  );
}

export default App;
